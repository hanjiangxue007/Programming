#include <stdio.h>

int mult ( int x, int y );

int main()
{
  int x;
  int y;
  
  printf("Please input two numbers to be multiplied:\n" );	// donot give spaces between \n and "
  scanf(" %d%d",&x,&y );
  printf( "The product of your two numbers is %d\n", mult( x, y ) );
  getchar(); 
}
//*************************************
//writing the function

int mult (int x, int y)
{
  return x * y;
}
//*************The End.
